  int arr[] = {20, 40,10, 8 ,45};
  int n = 5;